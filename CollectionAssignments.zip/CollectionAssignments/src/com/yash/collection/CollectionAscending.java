package com.yash.collection;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionAscending {

	public static void main(String[] args) {
		List<Integer>listNumber=Arrays.asList(10,30,20,15,25);
		Collections.sort(listNumber);
		System.out.println(listNumber);
	}

}
