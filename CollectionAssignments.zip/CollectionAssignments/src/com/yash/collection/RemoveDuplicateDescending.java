package com.yash.collection;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class RemoveDuplicateDescending {

	public static void main(String[] args) {
		List<String>nameList=Arrays.asList("someshwar","mahesh","anurag","someshwar");
		Set<String>setList=new TreeSet<>(nameList);
		setList.forEach(System.out::println);
	}

}
