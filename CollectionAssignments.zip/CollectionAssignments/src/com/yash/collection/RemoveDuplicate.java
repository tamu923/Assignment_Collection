package com.yash.collection;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class RemoveDuplicate {

	public static void main(String[] args) {
		List<Integer>list=Arrays.asList(20,10,30,35,20,30,40);
		Set<Integer>setList=new TreeSet<>(list);
		setList.forEach(System.out::println);
	}

}
