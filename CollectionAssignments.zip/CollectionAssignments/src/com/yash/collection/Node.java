package com.yash.collection;

public class Node {
	int data;
    Node left, right;
     
    Node(int d) {
        data = d;
        left = right = null;
    }
}
