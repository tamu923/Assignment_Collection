package com.yash.collection;


public class BinarySearch {
	public static void main(String[] args) {
		int[] number= {15,10,25,22,30};
		for(int i=0;i<number.length-1;i++) {
			for(int j=i+1;j<number.length;j++) {
				if(number[i]>number[j]) {
					int temp=number[i];
					number[i]=number[j];
					number[j]=temp;
				}
			}
		}
		for(int k=0;k<number.length;k++) {
			System.out.println("Array elements are "+number[k]);
		}
		int index=35;
		BinarySearch.binarySearch(number,index);
	}
	public static void binarySearch(int[] arr,int element) {
		int start=0,end=arr.length-1,mid=(end-start)/2;
		if(element==arr[mid]) {
			System.out.println(" Index element in the middle of the array "+element);
		}
		else if(arr[mid]>element) {
			for(int i=0;i<=mid;i++) {
				if(arr[i]==element) {
					System.out.println(" Index Element in the left side of the array "+element);
				}
			}
			System.out.println("element is not present ");
		}
		else if(arr[mid]<element) {
			for(int i=mid;i<=end;i++) {
				if(arr[i]==element) {
					System.out.println(" Index Element in the right side of the array "+element);
				}
			}
				System.out.println("element is not present ");
		}
		
	}
}
